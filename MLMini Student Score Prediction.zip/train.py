"""Breast Cancer Diagnosis - ML pipeline (classification).
Run: python train.py
Steps: load -> EDA -> preprocess -> model comparison (CV) -> tuning -> test evaluation -> insights -> save model.
"""
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, confusion_matrix, ConfusionMatrixDisplay,
                             RocCurveDisplay, classification_report)
from sklearn.inspection import permutation_importance

SEED = 42

# 1. Load data (0 = malignant, 1 = benign in sklearn)
data = load_breast_cancer(as_frame=True)
X, y = data.data, data.target
print(f"Samples: {X.shape[0]}, Features: {X.shape[1]}")
print("Missing values:", int(X.isna().sum().sum()))
print("Class balance:\n", y.map({0: "malignant", 1: "benign"}).value_counts(normalize=True).round(3))

# 2. EDA plot: class distribution + feature correlation with target
fig, ax = plt.subplots(1, 2, figsize=(12, 4))
y.map({0: "Malignant", 1: "Benign"}).value_counts().plot.bar(ax=ax[0], color=["#4c78a8", "#e45756"])
ax[0].set_title("Class distribution")
X.corrwith(y).sort_values().tail(30).plot.barh(ax=ax[1], figsize=(12, 6))
ax[1].set_title("Correlation with 'benign' label")
plt.tight_layout(); plt.savefig("eda.png", dpi=120); plt.close()

# 3. Split (stratified) - test set untouched until the end
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=SEED)

# 4. Preprocessing inside the pipeline (prevents data leakage)
def make(model):
    return Pipeline([("impute", SimpleImputer(strategy="median")),
                     ("scale", StandardScaler()),
                     ("model", model)])

models = {
    "Logistic Regression": make(LogisticRegression(max_iter=2000)),
    "SVM (RBF)": make(SVC(probability=True, random_state=SEED)),
    "Random Forest": make(RandomForestClassifier(n_estimators=300, random_state=SEED)),
    "Gradient Boosting": make(GradientBoostingClassifier(random_state=SEED)),
}

# 5. Compare models with 5-fold CV (on training data only)
cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
cv_scores = {}
for name, pipe in models.items():
    s = cross_val_score(pipe, X_tr, y_tr, cv=cv, scoring="f1")
    cv_scores[name] = (s.mean(), s.std())
    print(f"{name:22s} CV F1 = {s.mean():.4f} +/- {s.std():.4f}")
best_name = max(cv_scores, key=lambda k: cv_scores[k][0])
print("Best by CV:", best_name)

# 6. Hyperparameter tuning of the best model
grids = {
    "Logistic Regression": {"model__C": [0.01, 0.1, 1, 10]},
    "SVM (RBF)": {"model__C": [0.1, 1, 10], "model__gamma": ["scale", 0.01, 0.001]},
    "Random Forest": {"model__max_depth": [None, 5, 10], "model__min_samples_leaf": [1, 2, 4]},
    "Gradient Boosting": {"model__learning_rate": [0.05, 0.1], "model__n_estimators": [100, 200]},
}
gs = GridSearchCV(models[best_name], grids[best_name], cv=cv, scoring="f1", n_jobs=-1)
gs.fit(X_tr, y_tr)
final = gs.best_estimator_
print("Best params:", gs.best_params_)

# 7. Final evaluation on held-out test set
pred = final.predict(X_te)
proba = final.predict_proba(X_te)[:, 1]
metrics = {
    "model": best_name,
    "accuracy": accuracy_score(y_te, pred),
    "precision": precision_score(y_te, pred),
    "recall": recall_score(y_te, pred),
    "f1": f1_score(y_te, pred),
    "roc_auc": roc_auc_score(y_te, proba),
}
# Clinical note: the costliest error is calling a malignant case "benign"
tn, fp, fn, tp = confusion_matrix(y_te, pred).ravel()
metrics["malignant_missed"] = int(fp)   # predicted benign (1) but actually malignant (0)
print("\nTEST RESULTS:", json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in metrics.items()}, indent=2))
print(classification_report(y_te, pred, target_names=["malignant", "benign"]))

fig, ax = plt.subplots(1, 2, figsize=(11, 4))
ConfusionMatrixDisplay.from_predictions(y_te, pred, display_labels=["Malignant", "Benign"], ax=ax[0], cmap="Blues")
RocCurveDisplay.from_predictions(y_te, proba, ax=ax[1])
ax[0].set_title("Confusion matrix"); ax[1].set_title("ROC curve")
plt.tight_layout(); plt.savefig("evaluation.png", dpi=120); plt.close()

# 8. Insights: permutation importance (model-agnostic)
imp = permutation_importance(final, X_te, y_te, n_repeats=20, random_state=SEED, scoring="f1")
imp_s = pd.Series(imp.importances_mean, index=X.columns).sort_values(ascending=False)
print("\nTop 10 most influential features:\n", imp_s.head(10).round(4))
imp_s.head(10)[::-1].plot.barh(figsize=(7, 4), title="Top 10 features (permutation importance)")
plt.tight_layout(); plt.savefig("importance.png", dpi=120); plt.close()

# 9. Save artefacts for the app
joblib.dump({"model": final, "features": list(X.columns), "top": list(imp_s.head(8).index),
             "medians": X.median().to_dict(), "min": X.min().to_dict(), "max": X.max().to_dict()},
            "model.joblib")
json.dump(metrics, open("metrics.json", "w"), indent=2)
print("Saved model.joblib, metrics.json, eda.png, evaluation.png, importance.png")
