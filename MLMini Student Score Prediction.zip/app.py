"""Streamlit app: pip install streamlit ; streamlit run app.py  (run train.py first)"""
import joblib, json
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Breast Tumor Classifier", page_icon="🩺")
art = joblib.load("model.joblib")
model, feats, top = art["model"], art["features"], art["top"]

st.title("🩺 Breast Tumor Classifier")
st.caption("Educational demo – not a medical device.")

tab1, tab2 = st.tabs(["Predict", "Model performance"])
with tab1:
    st.write("Adjust the 8 most influential measurements (others use dataset medians).")
    row = dict(art["medians"])
    for f in top:
        lo, hi, med = art["min"][f], art["max"][f], art["medians"][f]
        row[f] = st.slider(f, float(lo), float(hi), float(med))
    if st.button("Classify"):
        p = model.predict_proba(pd.DataFrame([row])[feats])[0, 1]
        if p >= 0.5: st.success(f"Likely BENIGN (confidence {p:.1%})")
        else:        st.error(f"Likely MALIGNANT (confidence {1-p:.1%})")
with tab2:
    m = json.load(open("metrics.json"))
    st.json(m)
    st.image("evaluation.png"); st.image("importance.png"); st.image("eda.png")
